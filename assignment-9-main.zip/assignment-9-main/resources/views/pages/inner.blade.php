@extends('index')
@section('content')
    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
        <div class="container">
  
          @include('partials.nav')
  
        </div>
      </section><!-- End Breadcrumbs -->
  
      <section class="inner-page">
        <div class="container">
          <p>
            Example inner page template
          </p>
        </div>
      </section>
@endsection